<?php
include 'php/class/Gestionnaire.php';

// $test = new Bdd();
// var_dump($test);
?>
<h2 class="text-center fw-lighter leTitre">Les Utilisateurs</h2>
    
    
    <div class="container">
        


























	</div><!-- Fermeture du premier container -->

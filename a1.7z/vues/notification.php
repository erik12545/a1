<div class="notificationPageBody">
    <h1 class="text-center">Les Notifications</h1>
</div>
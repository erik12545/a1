<h2 class="text-center fw-lighter leTitre">Les Projets</h2>
    
    
    <div class="container">
        
        <!-- Les Alerts -->
		<div class="shadow-lg alert alert-danger alert-dismissible fade show" role="alert">
			<strong>Alerte !!</strong> Il y a un probleme au niveau du projet 56
			<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
		</div>



























	</div><!-- Fermeture du premier container -->
